package new1;

import java.util.Arrays;

public class noDups {

	public static void main(String[] args) {
		int a[] = {20,100,10,80,70,1,0,-1,2,10,15,300,7,6,2,18,19,21,9,0};
		a = duplicateElement(a); // passing an array to a different method

		for (int i = 0; i < a.length; i++) {
			System.out.print(" "+a[i]);
		}
		}
	// Method created
	private static int[] duplicateElement(int[] a) { 
		//Creating a loop to check for duplicates
		for(int i=0;i<a.length;i++) { 
			//Loop to comparing the index positions
			for (int n = i+1; n < a.length; n++) {
				if(a[i] == a[n]) {
					a = deleteElement(a, n); // Method if the are duplicates send them to this method
				}
			}
		}
		
		return a;
	}
	private static int[] deleteElement(int[] a, int Index) {
		if(Index < 0 || Index > a.length) {
			System.out.println("Array out of bound");
			return a;
		}
		int result[] = new int[a.length-1];
		for(int i=0; i<result.length; i++) {
			if(i<Index) {
				result[i] = a[i];
			}else {
				result[i] = a[i+1];
			}
		}
		return result;
	}

	}
