package new1;

import java.util.Arrays;
import java.util.Scanner;

public class identical {
	//Defining main method
	public static void main(String[] args) {
		//Initializing data type,variables and value
		//int i = 0, n = 0;
		int array1 = 0;
		int array2 = 0;
		int [][] a = new int[array1][array2];
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter array list: ");
		array1 = scan.nextInt();
		
		System.out.println("Enter the second array list: ");
		array2 = scan.nextInt();
		//if else to compare and confirm the results from arrays
		if(array1 != array2)
		{	
			System.out.println("Not identical arrays");
		}	
		else if (array1 == array2)
		{
			System.out.println("Identical arrays");						
		}
		scan.close();
	}
}
