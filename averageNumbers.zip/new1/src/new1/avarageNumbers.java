package new1;

import java.util.Scanner;

public class avarageNumbers {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		byte negNum = 0, posNum = 0, sum = 0, value;
		
		System.out.println("Enter the value");
		value = input.nextByte();
		
		while (value != 0) {
			if (value < 0) {
				negNum++;
			}
			else {
				posNum++;
			}
			
			sum += value;
			
			System.out.println("Enter the value");
			value = input.nextByte();
			
		}
		
		System.out.println("Positive integers: " + posNum + 
				 "\nNegative integers: " + negNum +
				 "\nSum of all integers: " + sum +
				 "\nAverage of all integers: " + (sum / (posNum + negNum))
				 );
		
	}

}
