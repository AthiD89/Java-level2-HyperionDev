package new1;
import java.util.Scanner;

public class grades {
// Defining the main method
	public static void main(String[] args) {
		//Defining the input using scanner method
		Scanner input = new Scanner(System.in);
	// Initializing the variables
		int[] myTestResults = {41, 56, 68, 79, 95};
		double average;
	int sum = 0;
	//Looping through arrays
		for(int num : myTestResults) {
	sum += num;
	}
	int arrLength = myTestResults.length;
	//Calculating the average and printing out average number
	average = ((double)sum / (double)arrLength);
	System.out.println("Average: "+ average);
	
	//Printing the symbol averages
			if (average > 80 && average < 89) {
				System.out.println("Symbol A");
			} else if (average > 70 && average < 79) {
				System.out.println("Symbol B");
			}else if (average > 60 && average < 69) {
				System.out.println("Symbol C");
			}else if (average > 50 && average < 59) {
				System.out.println("Symbol D");
			}else if (average > 40 && average < 49) {
				System.out.println("Symbol E");
			}
	}

}
