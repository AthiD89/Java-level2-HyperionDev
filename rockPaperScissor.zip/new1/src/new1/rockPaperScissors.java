package new1;
import java.util.*;
import java.util.Random;
import java.util.Scanner;

public class rockPaperScissors {

	public static void main(String[] args) {
		Scanner console = new Scanner(System.in);
		Random generator = new Random();		
				
		final int ROCK = 0;
		final int PAPER = 1;
		final int SCISSORS = 2;
		
		int userChoice, computerChoice;		
		
		do{
			System.out.println("0: Rock\n1: Paper\n2: Scissors\n-1 to quit:");
			userChoice = console.nextInt();
			computerChoice = generator.nextInt(2) + 0;
			
			if(userChoice == ROCK){
				if(computerChoice == ROCK) {
				  System.out.println("Rock vs Rock: Tie Game");			    
				}
				else if(computerChoice == PAPER) {
					  System.out.println("Rock vs Paper: You lose");			    
					}
				else if(computerChoice == SCISSORS) {
					  System.out.println("Rock vs Scissors: You Win!");			    
					}								
			}
			else if(userChoice == PAPER){
				if(computerChoice == ROCK) {
				  System.out.println("Paper vs Rock: You lose");		    
				}
				else if(computerChoice == PAPER) {
					  System.out.println("Paper vs Paper: Tie Game");			    
					}
				else if(computerChoice == SCISSORS) {
					  System.out.println("Paper vs Scissors: You Win!");			    
					}								
			}
			else if(userChoice == SCISSORS){
				if(computerChoice == ROCK) {
				  System.out.println("Scissors vs Rock: You Win!");			    
				}
				else if(computerChoice == PAPER) {
					  System.out.println("Scissors vs Paper: You lose");			    
					}
				else if(computerChoice == SCISSORS) {
					  System.out.println("Scissors vs Scissors: Tie Game!");			    
					}								
			}
													
		}while(userChoice > 0);
		System.out.println("Thanks for playing the game");
		
		
		System.out.println("Rock Paper Scissors");
	}
}
