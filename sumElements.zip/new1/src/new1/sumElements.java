package new1;
import java.util.Scanner;
import java.text.DecimalFormat;

public class sumElements {
	//Defining main method Run|Debug
	public static void main(String[] args) {
		//Initializing variables and values also data type
		double [][] a;
		double[] n;
		Scanner input = new Scanner(System.in);
		int row, col, k = 0,i,j;
		double sum = 0;
		DecimalFormat f = new DecimalFormat("00.000");
		
		System.out.println("Enter raw and column size: ");
		row = input.nextInt();
		col = input.nextInt();
		
		a = new double[row][col];
		n = new double[col];
		
		System.out.println("Enter array elements: ");
		//for loop to get the rows and columns elements
		for(i = 0; i < row; i++) {
		for(j = 0; j < col; j++) {
			
	a[i][j] = input.nextDouble();
		}
		}
		
		//Finding the sum of columns
		for(i = 0; i < row; i++) {
		for(j = 0; j < col; j++) {
		
			sum = sum + a[j][i];
		}
			n[k] = sum;
			k++;
			sum = 0;
		
		}
	for(i=0; i<col; i++) {
	System.out.println("Sum of column" +(i +1)  + " is: "+f.format(n[i]));	
}	
}

}
