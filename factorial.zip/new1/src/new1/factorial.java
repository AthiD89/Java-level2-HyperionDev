package new1;

import java.util.Scanner;

public class factorial {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		//prompt user to enter number
		System.out.println("Enter any positive number");
		
		int number = scanner.nextInt();
		int result = 1;
		//Check if number is positive number
		if(number <= 0) {
			result = 1;
		}
		else {
			
			for(int i = 1; i <= number; i++) {
				
				result = result * i;
			}
		}
		
		System.out.println("The factorial of a number is: " + result);

	}

}
