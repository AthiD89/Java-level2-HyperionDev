package new1;

import java.io.File;
import java.util.Scanner;
//Changed class name to MathsEquations
public class MathsEquations {
	public static void main(String[] args) {
			
		final int NUMBER = 5;
		//Changed variable int1 to x and int2 to y
		int y = 0; int x = 0; long startTime = System.currentTimeMillis();
		String string1 = " "; Scanner string2 = new Scanner(System.in);
		//loops through the numbers
		while (x < NUMBER) {
			int number1 = (int)(Math.random() * 10);
			int number2 = (int)(Math.random() * 10);
			if (number1 < number2) {
				int temp= number1; number1 = number2; number2 = temp;
				}
			System.out.print("What is "+ number1 +" - "+ number2 +"? ");int answer = string2.nextInt();
			//Minus the  numbers and prints the answer
			if (number1 - number2 == answer){
				System.out.println("You are correct!");
				y++; // Increase the correct answer count
				}
			else
				System.out.println("Your answer is wrong.\n"+ number1
						+ " - " + number2 + " should be " + (number1 - number2)); x++;
						string1 += "\n" + number1 + "-"+ number2 + "=" + answer +
								((number1 - number2 == answer) ? " correct":" wrong");
						}
		//declares and initialize time
		long endTime = System.currentTimeMillis();
		long testTime = endTime - startTime;
		System.out.println("Correct count is " + y +"\nTest time is "
		+ testTime / 1000 + " seconds\n"+ string1);
}
}


